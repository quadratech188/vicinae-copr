#pragma once
#include "services/app-service/abstract-app-db.hpp"
#include "ui/action-pannel/action.hpp"

class OpenAppAction : public AbstractAction {

public:
  void setClearSearch(bool value) { m_clearSearch = value; }
  void execute(ApplicationContext *context) override;

  OpenAppAction(const std::shared_ptr<AbstractApplication> &app, const QString &title,
                const std::vector<QString> args);

private:
  std::shared_ptr<AbstractApplication> application;
  std::vector<QString> args;
  bool m_clearSearch = false;
};

class OpenRawProgramAction : public AbstractAction {
  QString m_prog;
  std::vector<QString> m_args;
  bool m_clearSearch = false;

  void execute(ApplicationContext *context) override;

public:
  void setClearSearch(bool value) { m_clearSearch = value; }
  QString title() const override { return "Execute program"; }
  std::optional<ImageURL> icon() const override { return ImageURL::builtin("terminal"); }

  OpenRawProgramAction(const QString &prog, const std::vector<QString> args);
};
