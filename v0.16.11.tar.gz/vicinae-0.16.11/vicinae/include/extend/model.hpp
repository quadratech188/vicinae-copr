#pragma once
#include <QList>
#include <QString>
#include <qjsonarray.h>
#include <qjsonobject.h>

// event handlers are simple IDs that are used to communicate
// back the event
using EventHandler = QString;
