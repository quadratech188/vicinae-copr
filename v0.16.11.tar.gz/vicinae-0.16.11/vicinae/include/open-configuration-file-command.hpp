#pragma once
#include "command.hpp"
#include "omnicast.hpp"
#include "service-registry.hpp"
#include "ui/toast/toast.hpp"

class OpenConfigurationFileCommand : public CommandContext {
public:
  void load(const LaunchProps &props) override {
    auto appDb = ServiceRegistry::instance()->appDb();
    auto configFile = Omnicast::configDir() / "omnicast.json";

    if (auto opener = appDb->findBestOpener(configFile.c_str())) {
      appDb->launch(*opener, {configFile.c_str()});
      requestWindowClose();
      return;
    }

    if (auto browser = appDb->textEditor()) {
      appDb->launch(*browser, {configFile.c_str()});
      context()->navigation->closeWindow();
      return;
    }

    requestToast("No opener available for this file", ToastPriority::Danger);
  }

  OpenConfigurationFileCommand(const std::shared_ptr<AbstractCmd> &command) : CommandContext(command) {}
};
