import React, { ReactNode } from "react";
export declare const NavigationProvider: React.FC<{
	root: ReactNode;
}>;
//# sourceMappingURL=navigation-provider.d.ts.map
