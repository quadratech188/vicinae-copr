# Vicinae Extension

Congratulations on generating your new Vicinae extension!

You can install the required dependencies and run your extension in development mode like so:

```bash
npm install
npm run dev
```
If you want to build the production bundle, simply run:

```bash
npm run build
```
