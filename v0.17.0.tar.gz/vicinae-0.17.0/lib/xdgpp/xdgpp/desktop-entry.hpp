#pragma once
#include "desktop-entry/entry.hpp"
#include "desktop-entry/file.hpp"
#include "desktop-entry/iterator.hpp"
