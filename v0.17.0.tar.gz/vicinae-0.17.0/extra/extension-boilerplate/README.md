# Template extension

This extension is a collection of command templates to build extensions from.

The content of this repository is also used to generate the build time assets required to provide the "Create Extension" command
from within Vicinae (`vicinae://extensions/vicinae/developer/create`)

To make developing templates easy, this repo itself is a valid Vicinae extension and you can run it in development mode like any other:

```
npm install
npm run dev
```
