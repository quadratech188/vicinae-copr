import { randomUUID } from "crypto";

// legacy raycast util
export const randomId = randomUUID;
