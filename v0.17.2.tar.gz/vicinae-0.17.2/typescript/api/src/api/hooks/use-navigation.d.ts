/// <reference types="react" />
export declare const useNavigation: () => {
	push: (node: import("react").ReactNode) => void;
	pop: () => void;
};
//# sourceMappingURL=use-navigation.d.ts.map
